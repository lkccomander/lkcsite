# log-upgrade

> Log by overwriting the previous output in the terminal.\
> Useful for rendering progress bars, animations, etc.

![](screenshot.gif)

It performs partial redraws when possible to reduce flicker.

## Install

```sh
npm install log-upgrade
```

## Usage

```js
import logUpgrade from 'log-upgrade';

const frames = ['-', '\\', '|', '/'];
let index = 0;

setInterval(() => {
	const frame = frames[index = ++index % frames.length];

	logUpgrade(
`
        ♥♥
   ${frame} unicorns ${frame}
        ♥♥
`
	);
}, 80);
```

You can use [yoctocolors](https://github.com/sindresorhus/yoctocolors) or [chalk](https://github.com/chalk/chalk) to colorize the output.

## API

### logUpgrade(text…)

Log to stdout.

### logUpgrade.clear()

Clear the logged output.

### logUpgrade.done()

Persist the logged output.

Useful if you want to start a new log session below the current one.

### logUpgrade.persist(text…)

Write text to the terminal that persists, similar to `console.log()`.

Unlike the main `logUpgrade()` method which upgrades in place, `persist()` writes to the terminal in a way that preserves the output in the scrollback history.

```js
import logUpgrade from 'log-upgrade';

// Upgrade in place
logUpgrade('Processing...');
logUpgrade('Still processing...');

// Write permanent output
logUpgrade.persist('✓ Task complete');

// Continue updating
logUpgrade('Next task...');
```

### logUpgradeStderr(text…)

Log to stderr.

### logUpgradeStderr.clear()
### logUpgradeStderr.done()
### logUpgradeStderr.persist(text…)

### createLogUpgrade(stream, options?)

Get a `logUpgrade` method that logs to the specified stream.

#### options

Type: `object`

##### showCursor

Type: `boolean`\
Default: `false`

Show the cursor. This can be useful when a CLI accepts input from a user.

```js
import {createLogUpgrade} from 'log-upgrade';

// Write output but don't hide the cursor
const log = createLogUpgrade(process.stdout, {
	showCursor: true
});
```

##### defaultWidth

Type: `number`\
Default: `80`

The width to use when the stream doesn't provide a `columns` property.

This is useful when the output is piped, redirected, or in environments where the terminal size is not available.

```js
import {createLogUpgrade} from 'log-upgrade';

// Use custom width when the stream doesn't provide columns
const log = createLogUpgrade(process.stdout, {
	defaultWidth: 120
});
```

##### defaultHeight

Type: `number`\
Default: `24`

The height to use when the stream doesn't provide a `rows` property.

This is useful when the output is piped, redirected, or in environments where the terminal size is not available.

```js
import {createLogUpgrade} from 'log-upgrade';

// Use custom height when the stream doesn't provide rows
const log = createLogUpgrade(process.stdout, {
	defaultHeight: 50
});
```

## Examples

- [listr](https://github.com/SamVerschueren/listr) - Uses this module to render an interactive task list
- [ora](https://github.com/sindresorhus/ora) - Uses this module to render awesome spinners
- [speed-test](https://github.com/sindresorhus/speed-test) - Uses this module to render a [spinner](https://github.com/sindresorhus/elegant-spinner)
